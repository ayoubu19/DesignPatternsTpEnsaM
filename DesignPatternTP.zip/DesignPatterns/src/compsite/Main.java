package compsite;

public class Main {

	public static void main(String[] args) {
		Formule carte = new Formule("Restaurant");
		
		Formule fEnfant = new Formule("Formule enfant");
		fEnfant.ajouter(new Plat("Salade carotte"));
		fEnfant.ajouter(new Plat("Steak 50g"));
		carte.ajouter(fEnfant);
		
		Formule fAdulte = new Formule("Formule adulte");
		fAdulte.ajouter(new Plat("Salade cretoise"));
		fAdulte.ajouter(new Plat("Super macaronni"));
		carte.ajouter(fAdulte);
		
		carte.ajouter(new Plat("Dessert Vanille"));
		
		carte.afficher();

	}

}
