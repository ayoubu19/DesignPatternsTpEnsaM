package compsite;
//composant interface 
public interface  FormuleComp {

	public  void afficher();
	
}
