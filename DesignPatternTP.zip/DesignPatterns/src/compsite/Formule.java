package compsite;

import java.util.ArrayList;

public class Formule implements FormuleComp  {
private String nomFormule;
	
	private ArrayList<FormuleComp> formulelist=new ArrayList<FormuleComp>();
	
	public Formule(String string) {
		//constructeur
		
		this.setNomFormule(string);
			}

	

	
	public void ajouter(FormuleComp fcmp) {
		formulelist.add(fcmp);
	}


// reccursivite : parcours du Formulelist si trouve  fromule il affiche son nom et le parcours 
//et si trouve  plat il affiche son nom et complete le parcours jusqu le dernier elmnt 	

	@Override
	public void afficher() {
		//pour afficher le nom du formule
		System.out.println(this.nomFormule+"\n");
	
		for(FormuleComp fcmp:formulelist) 
        { 
			
            fcmp.afficher(); 
        } 
		
	}




	public String getNomFormule() {
		return nomFormule;
	}




	public void setNomFormule(String nomFormule) {
		this.nomFormule = nomFormule;
	}


}


