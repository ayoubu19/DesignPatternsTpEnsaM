package compsite;
//leaf : objet terminal
public class Plat implements FormuleComp {
	String nomPlat;
	
	
	
	public Plat(String string) {
		this.nomPlat=string;
	}


	@Override
	public void afficher() {
		System.out.println("     --je suis le plat "+nomPlat+"\n");
		
	}
	
	
	}
