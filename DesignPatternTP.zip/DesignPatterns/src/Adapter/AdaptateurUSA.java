package Adapter;

public class AdaptateurUSA extends PriseEU{
    private PriseUSA p;
    public AdaptateurUSA(PriseUSA p){
        this.p = p;
        //super(p.val);
    }

    public void moins(int m){
        this.p.val -= m;
        System.out.println(this.p.val);
    }

    public void plus(int pl){
        this.p.val += pl;
        System.out.println(this.p.val);
    }
}
