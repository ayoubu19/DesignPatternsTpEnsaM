package Adapter;

public abstract class PriseUSA {
    protected int val = 0;
    public PriseUSA(int val){
        this.val = val;
    }

    public abstract void moins(int m);
    public abstract void plus(int p);
}
