package Adapter;

public class Main {
    public static void main(String[] args){
        PriseUSA prisePs3 = new PrisePS3();
        PriseEU adapteur = new AdaptateurUSA(prisePs3);

        adapteur.moins(10);
        adapteur.plus(10);
        adapteur.moins(-6);
        adapteur.plus(20);
    }
}
