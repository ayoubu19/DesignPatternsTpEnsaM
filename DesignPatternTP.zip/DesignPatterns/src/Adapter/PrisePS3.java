package Adapter;

public class PrisePS3 extends PriseUSA{
    public PrisePS3(){
        super(23);
    }

    public void moins(int m){
        this.val -= m;
        System.out.println(this.val);
    }

    public void plus(int p){
        this.val += p;
        System.out.println(this.val);
    }
}
