package Adapter;

public abstract class PriseEU {
    protected int val = 1;
    public PriseEU(){

    }
    public PriseEU(int val){
        this.val = val;
    }

    public abstract void plus(int p);
    public abstract void moins(int m);
}
