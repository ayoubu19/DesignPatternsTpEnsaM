package abstractfactory;

public class FabriqueComposantLeger implements FabriqueComposantTable {

	@Override
	public Vice createVice() {
		// TODO Auto-generated method stub
		return new ViceLeger();
	}

	@Override
	public Planche createPlanche() {
		// TODO Auto-generated method stub
		return new PlancheLeger();
	}

}
