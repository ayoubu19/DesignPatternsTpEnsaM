package abstractfactory;

public class PlancheLeger extends Planche {

	@Override
	String afficherMatiere() {
		return matiere;
	}

}
