package abstractfactory;

public interface FabriqueTable {
	abstract Table createTable();
}
