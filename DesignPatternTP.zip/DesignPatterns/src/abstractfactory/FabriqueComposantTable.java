package abstractfactory;

public interface FabriqueComposantTable {
	public Vice createVice();
	public Planche createPlanche();
}
