package abstractfactory;

public class FabriqueTableSolide implements FabriqueTable {
	private FabriqueComposantTable fComp;
	public FabriqueTableSolide(FabriqueComposantTable fComp) {
		this.fComp=fComp;
	}

	@Override
	public Table createTable() {
		Vice viceSolide=fComp.createVice();
		viceSolide.setMatiere("Fer");
		Planche plancheSolide=fComp.createPlanche();
		plancheSolide.setMatiere("Fer");
		Table tableSolide=new Table();
		tableSolide.setVice(viceSolide);
		tableSolide.setPlanche(plancheSolide);
		return tableSolide;
	}

}
