package abstractfactory;

public class Main {

	public static void main(String[] args) {
		FabriqueComposantTable fComp = new FabriqueComposantSolide();
		FabriqueTable fTable=new FabriqueTableSolide(fComp);
		Table table = fTable.createTable();
		System.out.println(table.toString());
		
		fComp = new FabriqueComposantLeger();
		fTable=new FabriqueTableLeger(fComp);
		table = fTable.createTable();
		System.out.println(table.toString());
		

	}

}
