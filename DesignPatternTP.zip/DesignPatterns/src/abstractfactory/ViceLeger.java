package abstractfactory;

public class ViceLeger extends Vice {
	@Override
	String afficherMatiere() {
		return matiere;
	}
}
