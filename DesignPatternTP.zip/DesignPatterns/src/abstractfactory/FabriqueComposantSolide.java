package abstractfactory;

public class FabriqueComposantSolide implements FabriqueComposantTable {

	@Override
	public Vice createVice() {
		// TODO Auto-generated method stub
		return new ViceSolide();
	}

	@Override
	public Planche createPlanche() {
		// TODO Auto-generated method stub
		return new PlancheSolide();
	}

}
