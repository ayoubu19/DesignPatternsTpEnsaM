package abstractfactory;

public class ViceSolide extends Vice {
	@Override
	String afficherMatiere() {
		return matiere;
	}
}
