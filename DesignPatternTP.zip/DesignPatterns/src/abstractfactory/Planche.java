package abstractfactory;

public abstract class Planche {
	String matiere;

	public String getMatiere() {
		return matiere;
	}

	public void setMatiere(String matiere) {
		this.matiere = matiere;
	}
	abstract String afficherMatiere();

}
