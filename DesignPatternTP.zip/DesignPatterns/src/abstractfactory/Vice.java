package abstractfactory;

public abstract class Vice {
	String matiere;

	public String getMatiere() {
		return matiere;
	}

	public void setMatiere(String matiere) {
		this.matiere = matiere;
	}
	
	abstract String afficherMatiere();

	

}
