package abstractfactory;

public class FabriqueTableLeger implements FabriqueTable {
	private FabriqueComposantTable fComp;
	public FabriqueTableLeger(FabriqueComposantTable fComp) {
		this.fComp=fComp;
	}

	@Override
	public Table createTable() {
		Vice viceLeger=fComp.createVice();
		viceLeger.setMatiere("Plastic");
		Planche plancheLeger=fComp.createPlanche();
		plancheLeger.setMatiere("Plastic");
		Table tableLeger=new Table();
		tableLeger.setVice(viceLeger);
		tableLeger.setPlanche(plancheLeger);
		return tableLeger;
	}

}