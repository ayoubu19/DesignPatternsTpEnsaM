package abstractfactory;

public  class Table {
	private Vice vice;
	private Planche planche;
	public Vice getVice() {
		return vice;
	}
	public void setVice(Vice vice) {
		this.vice = vice;
	}
	public Planche getPlanche() {
		return planche;
	}
	public void setPlanche(Planche planche) {
		this.planche = planche;
	}
	@Override
	public String toString() {
		return "Table compos�e de vice de mati�re " + vice.afficherMatiere() + ",et planche de mati�re " + planche.afficherMatiere();
	}
	
}
