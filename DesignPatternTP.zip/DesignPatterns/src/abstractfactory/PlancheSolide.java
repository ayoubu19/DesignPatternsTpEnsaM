package abstractfactory;

public class PlancheSolide extends Planche {

	@Override
	String afficherMatiere() {
		return matiere;
	}

}
