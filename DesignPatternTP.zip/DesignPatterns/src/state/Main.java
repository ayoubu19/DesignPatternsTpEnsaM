package state;

import java.io.IOException;
import java.util.Scanner;

public class Main {

	private static Scanner is;

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		 is = new Scanner(System.in); 
		 
		 MyContext mc = new MyContext();
		
		 System.out.println("Press 'Enter' ");
			
		
		while(true) {
		
			
			 is.nextLine();
		
		     mc.pull();
		  
			 System.out.println("Press 'Enter' ");
			

		}
		

	}

}

