package state;

public interface State {
	
	public void handle();

}
