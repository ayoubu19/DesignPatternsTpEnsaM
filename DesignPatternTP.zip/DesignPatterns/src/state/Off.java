package state;

public class Off  implements State {

	@Override
	public void handle() {
		// TODO Auto-generated method stub
		System.out.println(" > off");
		System.out.println();
		
	}

}
