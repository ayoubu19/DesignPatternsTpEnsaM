package state;

import java.util.ArrayList;
import java.util.Iterator;

public class MyContext {
	
	private ArrayList<State> stateList = new ArrayList<State>();
	private State state ; 
	Iterator <State> it;
	
	
	public MyContext() {
		
		stateList.add(new Off());
		stateList.add(new LowSpeed());
		stateList.add(new MediumSpeed());
	    stateList.add(new HighSpeed());
		
		
		// iterator 
		it = stateList.iterator();
	}
	
	

   
	public void pull() {
		
		// TODO Auto-generated method stub
		
		
		
		if (!(it.hasNext())) {
			
		    
		    it = stateList.iterator();
		   
		    state=it.next();
		    
		    
			
		}
		
		else  {

			   
			state=it.next();
		
		}
		
		
		state.handle();
		
		
		
		
	}




	
}
