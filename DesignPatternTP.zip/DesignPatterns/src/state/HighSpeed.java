package state;

public class HighSpeed implements State {

	@Override
	public void handle() {
		// TODO Auto-generated method stub
		
		System.out.println(" > high speed ");
		System.out.println();
		
	}

}
