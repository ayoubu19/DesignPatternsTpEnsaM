package state;

public class MediumSpeed implements State {

	@Override
	public void handle() {
		// TODO Auto-generated method stub
		System.out.println(" > meduim speed");
		System.out.println();
		
	}

}
