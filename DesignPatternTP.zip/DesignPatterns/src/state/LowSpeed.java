package state;

public class LowSpeed implements State {

	@Override
	public void handle() {
		// TODO Auto-generated method stub
		System.out.println(" > low speed");
		System.out.println();
		
	}

}
