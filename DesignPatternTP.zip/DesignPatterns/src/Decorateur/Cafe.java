package Decorateur;

public class Cafe extends Boisson{
    public Cafe(){
        super("Cafe noir de la chine", 12.5);
    }

    public Double prix(){
        return this.prix;
    }

    public String getDescription(){
        return this.desc;
    }
}
