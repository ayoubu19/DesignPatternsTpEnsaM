package Decorateur;

public abstract class Boisson {
    protected String desc;
    protected Double prix;

    public Boisson(String d, Double p){
        this.desc = d;
        this.prix = p;
    }

    public abstract Double prix();
    public abstract String getDescription();
}
