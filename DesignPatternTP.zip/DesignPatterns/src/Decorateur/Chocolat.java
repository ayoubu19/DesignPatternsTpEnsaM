package Decorateur;

public class Chocolat extends CafeDecorator{
    public Chocolat(Boisson b){
        super(b.desc,b.prix);
    }

    public Double prix(){
        return this.prix;
    }

    public String getDescription(){
        return this.desc;
    }
}
