package Decorateur;

public class Main {
    public static void main(String[] args){
        Boisson superCafe = new Cafe();

        System.out.println("super cafe: " + superCafe.prix());

        superCafe = new Chocolat(superCafe);
        superCafe = new Sucre(superCafe);

        System.out.println("Super cafe: " + superCafe.getDescription());
        System.out.println("Super cafe: " + superCafe.prix());
    }
}
