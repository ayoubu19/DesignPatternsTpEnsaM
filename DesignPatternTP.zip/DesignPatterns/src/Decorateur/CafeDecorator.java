package Decorateur;

public abstract class CafeDecorator extends Boisson{
    public CafeDecorator(String type,Double prix){
        super(type,prix);
    }
}
