package iterator;

public interface Iterator {
     
	public boolean isDone();
	public Object currentItem();
	public void next();
	public void first();
	
}
