package iterator;

import java.util.ArrayList;

public class 
MoviesListIterator implements Iterator {
    
	ArrayList<String> MoviesList  ; 
	
	int pos = 0 ;
	
	public MoviesListIterator(ArrayList<String> moviesList) {
		// TODO Auto-generated constructor stub
		this.MoviesList=moviesList;
	}

	@Override
	public boolean isDone() {
		// TODO Auto-generated method stub
		
		 if (pos >= MoviesList.size() ||  MoviesList.get(pos)== null)  return true; 
		
		 else  return false;
	                     
		           
		      
		
	}

	@Override
	public Object currentItem() {
		// TODO Auto-generated method stub
		return  MoviesList.get(pos);
	}

	@Override
	public void next() {
		// TODO Auto-generated method stub
		
		
		pos++;
		
		
		
	}

	@Override
	public void first() {
		// TODO Auto-generated method stub
	    pos=0;
	}

}
