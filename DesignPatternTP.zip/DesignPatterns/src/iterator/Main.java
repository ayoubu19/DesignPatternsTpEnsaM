package iterator;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Movies Mymovies = new Movies();
		Mymovies.append("sherlock Holmes");
		Mymovies.append("Shakespeare in love ");
		Mymovies.append("matrix");
		Mymovies.append("American Pie 2 ");
		Mymovies.append("Bridget Jones diary ");
		Mymovies.append("Hamlet");
		Mymovies.append("Harry Potter");
		
		MoviesListIterator myMovieIterator = (MoviesListIterator) Mymovies.creatIterator();
		while(!myMovieIterator.isDone()) {
			System.out.println(myMovieIterator.currentItem());
			myMovieIterator.next();
			
		}
		
		Mymovies.delete("matrix");
		
		System.out.println("------------------------------- ");
		
		System.out.println("la nouvelle liste : ");
		
		myMovieIterator.first();
		
		
		
		while(!myMovieIterator.isDone()) {
			
			
			System.out.println(myMovieIterator.currentItem());
			myMovieIterator.next();
			
		}
		
		

	}

	}


