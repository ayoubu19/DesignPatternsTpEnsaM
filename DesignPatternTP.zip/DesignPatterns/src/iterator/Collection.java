package iterator;

public interface Collection {

	public Iterator creatIterator();
	public void append (String movie);
	public void delete (String movie);
	
	

}
