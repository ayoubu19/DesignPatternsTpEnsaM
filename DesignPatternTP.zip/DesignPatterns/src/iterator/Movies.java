package iterator;

import java.util.ArrayList;

public class Movies implements Collection {
	
	ArrayList<String> MoviesList  ; 
	 
	   public Movies() {
		
		  MoviesList=new ArrayList<String>();
	}

	@Override
	public Iterator creatIterator() {
		// TODO Auto-generated method stub
		return new MoviesListIterator(MoviesList);
	}

	@Override
	public void append(String movie) {
		// TODO Auto-generated method stub
		
		MoviesList.add(movie);
		
		
		
	}

	@Override
	public void delete(String movie) {
		
		MoviesList.remove(movie);
		
		
		
		
	} 

}
