package singleton;

public class Singleton {

	static Singleton s ; 
	static int i=0;
	
	private Singleton() {
		
	}
	
	
	public static Singleton getInstance() {
		
		
		if (s==null) {
			 
			
			s= new Singleton();
			
			i++;
			
			
			
		}
		
		System.out.println(i);
		
		return s ; 
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
	public static void main(String[] args) {
		
		Singleton.getInstance();
		Singleton.getInstance();
		Singleton.getInstance();
		Singleton.getInstance();
		
		

	}

}
