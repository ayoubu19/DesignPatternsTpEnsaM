package bridge;

public class Samsung extends Televiseur {
	public Samsung() {
		this.setMarque("Samsung");
	}
}
