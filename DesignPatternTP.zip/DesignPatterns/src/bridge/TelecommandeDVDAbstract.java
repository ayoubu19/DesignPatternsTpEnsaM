package bridge;

public abstract class TelecommandeDVDAbstract extends TelecommandeAbstract {

	protected abstract void allumerDVD();

}
