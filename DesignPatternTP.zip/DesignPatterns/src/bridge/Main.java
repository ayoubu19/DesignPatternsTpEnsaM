package bridge;

public class Main {

	public static void main(String[] args) {
		Telecommande com = new TelecommandeDVD();
		
		com.setTeleviseur(new Samsung());
		com.off();
		com.on();
		com.choisirChaine(15);
		
		com.setTeleviseur(new LG());
		com.off();
		com.on();
		com.choisirChaine(15);
		
		((TelecommandeDVD)com).allumerDVD();

	}

}
