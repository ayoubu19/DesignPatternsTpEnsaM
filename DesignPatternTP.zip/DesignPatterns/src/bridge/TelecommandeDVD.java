package bridge;

public class TelecommandeDVD extends Telecommande {
	public void allumerDVD(){
		System.out.println("DVD is Allumer");
	}
}
