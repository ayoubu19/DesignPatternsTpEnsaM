package bridge;

public class LG extends Televiseur {
	public LG() {
		this.setMarque("LG");
	}
}
