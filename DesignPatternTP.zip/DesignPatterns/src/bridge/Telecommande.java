package bridge;

public class Telecommande extends TelecommandeAbstract {

	@Override
	protected void setTeleviseur(Televiseur tl) {
		System.out.println("Je suis La Telecommande"+tl.getMarque());
	}

	@Override
	protected void off() {
		System.out.println("TV is OFF");
	}

	@Override
	protected void on() {
		System.out.println("TV is ON");
	}

	@Override
	protected void choisirChaine(int i) {
		System.out.println("Chaine "+i+" is Selected");
		
	}

}
