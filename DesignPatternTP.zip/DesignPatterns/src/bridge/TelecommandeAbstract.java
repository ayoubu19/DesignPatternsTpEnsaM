package bridge;

public abstract class TelecommandeAbstract {

	protected abstract void setTeleviseur(Televiseur tl);

	protected abstract void off();

	protected abstract void on();

	protected abstract void choisirChaine(int i);
}
