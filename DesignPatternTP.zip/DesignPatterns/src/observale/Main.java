package observale;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
       
		AgenceTravail at =new AgenceTravail() ; 
		
		at.register(new DemandeurEmploi("Ahmed"));
		at.register(new DemandeurEmploi("Caroline"));
		at.register(new DemandeurEmploi("Soufiane"));
       // a chaque fois qu un nouveau travail est ajoute les demandeurs son au courant
		
		at.addJob(" IBM JOB");	
        at.addJob(" Google Job");
        
        at.register(new DemandeurEmploi("Ayoub"));
        
        at.addJob(" Facebook Job");
        
        System.out.println("===================================================================");
        System.out.println("\n");

		for(DemandeurEmploiInter observer:at.observers) 
        { 
			System.out.print("depuis son abonnement we notified le demandeur " +observer.getNom()+ " du jobs suivant : ");
			
            observer.afficherJobs();
            System.out.println();
        
        } 

	}

}
