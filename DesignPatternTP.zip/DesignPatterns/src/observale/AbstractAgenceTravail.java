package observale;

import java.util.ArrayList;



public abstract class AbstractAgenceTravail {
	
	protected ArrayList<DemandeurEmploiInter> observers =new ArrayList<DemandeurEmploiInter>();
	
	protected ArrayList<String> Jobs =new ArrayList<String>();
	
	public abstract void register(DemandeurEmploiInter  observer) ;
	
    public abstract void notifyDemandeurEmploi(DemandeurEmploiInter  observer ,String Job) ;
    
    public abstract void addJob(String Job) ; 
    
    
	

}
