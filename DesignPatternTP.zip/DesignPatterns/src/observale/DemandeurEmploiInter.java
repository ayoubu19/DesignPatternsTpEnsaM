package observale;

import java.util.ArrayList;

public abstract class DemandeurEmploiInter {
	
	private String nom ;
	protected ArrayList<String> Jobs =new ArrayList<String>();
	

	public DemandeurEmploiInter(String nom) {
		super();
		this.nom = nom;
	}
	
	
	public String getNom() {
		return nom;
	}


	public abstract void updateMyself(String Job);
	
	public abstract void afficherJobs();

}
