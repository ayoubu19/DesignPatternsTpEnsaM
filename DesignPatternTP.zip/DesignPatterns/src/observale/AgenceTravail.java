package observale;

public class AgenceTravail extends AbstractAgenceTravail{

	@Override
	public void register(DemandeurEmploiInter observer) {
		// TODO Auto-generated method stub
		
		this.observers.add(observer);
		
	}

	@Override
	public void notifyDemandeurEmploi(DemandeurEmploiInter observer , String Job ) {
		
		
		observer.updateMyself(Job);
		
	}

	@Override
	public void addJob(String Job) {
		// TODO Auto-generated method stub
		 
		Jobs.add(Job);
		
		for(DemandeurEmploiInter observer:this.observers) 
        { 
			
            this.notifyDemandeurEmploi(observer, Job);
            
        } 
		
		
		for(DemandeurEmploiInter observer:this.observers) 
        { 
			System.out.print("we notified le demandeur " +observer.getNom()+ " du nouveau job ajoutee  : " + Job);
           
           System.out.println();
        
        } 
		System.out.println("\n");
		
	}

}
