package observale;

public class DemandeurEmploi extends DemandeurEmploiInter {
	

	public DemandeurEmploi(String nom) {
		super(nom);
		// TODO Auto-generated constructor stub
	}


	
	
	
	@Override
	public void updateMyself(String Job) {
		
		
		this.Jobs.add(Job);

     
		
	}


	@Override
	public void afficherJobs() {
	   
	    
		for(String job:this.Jobs) 
        { 
			System.out.print(" - "+job);
           
            
        } 
		
	}

	
	
}
