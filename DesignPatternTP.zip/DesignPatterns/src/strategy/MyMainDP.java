package strategy;

public class MyMainDP {

	public static void clientCode(Solver solver) {
		solver.solve();
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Solver[] alogorithms = {
				new Impl1(),
				new Impl2()
		};
		
		for(int i=0 ; i<alogorithms.length ; i++){
			
			clientCode(alogorithms[i]);
		}

	}

}
