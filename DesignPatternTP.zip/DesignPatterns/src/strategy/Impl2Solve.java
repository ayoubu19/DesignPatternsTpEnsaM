package strategy;

public class Impl2Solve implements SolveBehaviour {

	@Override
	public void solve() {
		System.out.println("preProcess search-1 postProcess preprocess search-2");
		
	}

}
