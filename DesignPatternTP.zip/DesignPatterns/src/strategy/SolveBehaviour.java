package strategy;

public interface SolveBehaviour {
	
	public void solve();

}
