package strategy;

public class Impl1Solve implements SolveBehaviour {

	@Override
	public void solve() {
		// TODO Auto-generated method stub
		System.out.println("start nextTry1 isSolution-false nextTry isSolution-true stop");
	}

}
