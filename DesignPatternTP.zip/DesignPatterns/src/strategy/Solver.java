package strategy;

public class Solver {
    
	SolveBehaviour solvebehaviour ;
	
	public void solve() {
	   
		solvebehaviour.solve();
   }

}
