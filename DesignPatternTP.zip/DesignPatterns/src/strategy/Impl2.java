package strategy;

public class Impl2 extends Solver {
	
public Impl2() {
		
		this.solvebehaviour=new Impl2Solve();
		
	}

}
