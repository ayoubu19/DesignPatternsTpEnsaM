package strategy;

public class Impl1 extends Solver{

	public Impl1() {
		
		this.solvebehaviour=new Impl1Solve();
		
	}

}
