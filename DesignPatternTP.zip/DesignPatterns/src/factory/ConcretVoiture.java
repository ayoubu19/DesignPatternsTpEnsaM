package factory;

public class ConcretVoiture extends Voiture {

	@Override
	public String toString() {
		
		
		return "la voiture " + marque + " a ete cree avec succes";
	}

	
	
}
