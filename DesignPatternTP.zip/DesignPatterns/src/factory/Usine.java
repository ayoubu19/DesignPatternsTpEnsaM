package factory;

public interface Usine {

	public ConcretVoiture createVoiture(String marque);
	
}
