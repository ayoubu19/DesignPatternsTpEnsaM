package factory;

public abstract class Voiture {

	protected String marque ;
	
	public abstract String toString();

	public String getMarque() {
		return marque;
	}

	public void setMarque(String marque) {
		this.marque = marque;
	}
	
	
}
