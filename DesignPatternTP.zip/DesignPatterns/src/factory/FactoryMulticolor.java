package factory;

public class FactoryMulticolor implements Usine {

	@Override
	public ConcretVoiture createVoiture(String marque) {
		// TODO Auto-generated method stub
		ConcretVoiture v = new ConcretVoiture();
		
		v.setMarque(marque);
		
		
		return v ;
	}

	
	
	

}
