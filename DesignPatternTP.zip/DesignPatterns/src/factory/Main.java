package factory;

public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
      //creation de la Fabrique multicolor 
		Usine u = new FactoryMulticolor();
		ConcretVoiture v1 = u.createVoiture("407");
		
		System.out.println(v1.toString());
		
		
	}

	

}
